# ddg-tugas1
1. Download file project ini
2. Pindahkan style inline & internal css menjadi file external css (style.css) ke dalam sebuah folder (css)
3. Library css font awesome simpan di folder baru (css) dan ubah pada link href tersebut.
